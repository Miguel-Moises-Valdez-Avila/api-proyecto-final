// Obtener elementos del DOM
let username = document.getElementById('username'); // Campo de entrada para el nombre de usuario
let email = document.getElementById('email'); // Campo de entrada para el correo electrónico
let password = document.getElementById('password'); // Campo de entrada para la contraseña
let btnRegister = document.getElementById('register'); // Botón de registro

// Función asincrónica para consumir la API y registrar al usuario
async function apiwebII(credenciales){
    try {
        // URL de la API para el registro de usuarios
        let url = "http://localhost/api-webII/v1/usuarios/registro"; 
        
        // Realizar la petición POST a la API con las credenciales
        const response = await fetch(url, credenciales); 
        
        // Parsear la respuesta a formato JSON
        const data = await response.json();
        console.log(data);
        
        // Redirigir al usuario a la página de inicio de sesión
        location.href = './index.html';
       
    } catch (error) {
        // Manejar errores y mostrar en consola
        console.error('Error:', error);
    }
}

// Definir la función para obtener las credenciales del formulario
function credenciales(event) {
    // Prevenir la acción por defecto del botón (recargar la página)
    event.preventDefault(); 

    // Obtener valores de los campos de entrada
    let nombre_usuario = username.value;
    let correo = email.value;
    let contrasena = password.value;

    // Crear objeto con las credenciales
    let objeto_credenciales = {
        email: correo,
        password: contrasena,
        username: nombre_usuario
    };

    // Configuración de la petición POST
    const options = {
        method: 'POST', // Método HTTP a utilizar
        headers: {
            'Content-Type': 'application/json' // Tipo de contenido de la petición
        },
        body: JSON.stringify(objeto_credenciales) // Convertir objeto de credenciales a JSON
    };

    // Llamar a la función para consumir la API con las opciones configuradas
    apiwebII(options);

    //console.log(objeto_credenciales);
}

// Añadir el evento click al botón de registro para ejecutar la función credenciales
btnRegister.addEventListener('click', credenciales);
