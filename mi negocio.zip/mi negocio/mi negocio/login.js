// Obtener elementos del DOM,  proporcionar una interfaz para interactuar con el documento HTML
let email = document.getElementById('email'); // Campo de entrada para el email del usuario
let password = document.getElementById('password'); // Campo de entrada para la contraseña del usuario
let btnLogin = document.getElementById('login'); // Botón que el usuario presiona para iniciar sesión

// Función asincrónica para realizar la llamada a la API
async function apiwebII(credenciales){
    try {
        let url = "http://localhost/api-webII/v1/usuarios/login"; // URL de la API para el login
        const response = await fetch(url, credenciales); // Realizar la llamada a la API con las credenciales
        const data = await response.json(); // Obtener la respuesta en formato JSON
        
        // Guardar los datos del usuario en sessionStorage
        data.forEach(user => {
            sessionStorage.setItem('id_usuario', user.id); // Guardar el ID del usuario
            sessionStorage.setItem('token_usuario', user.token); // Guardar el token del usuario
        });
        
        location.href = './items.html'; // Redirigir a items.html tras el login exitoso
    } catch (error) {
        console.error('Error:', error); // Mostrar cualquier error en la consola
    }
}

// Función para manejar las credenciales del usuario
function credenciales(event) {
    event.preventDefault(); // Prevenir el comportamiento por defecto del formulario

    let correo = email.value; // Obtener el valor del campo de entrada email
    let contrasena = password.value; // Obtener el valor del campo de entrada password

    // Crear un objeto con las credenciales del usuario
    let objeto_credenciales = {
        email: correo,
        password: contrasena
    };

    // Configuración de la solicitud a la API
    const options = {
        method: 'POST', // Método HTTP a utilizar
        headers: {
            'Content-Type': 'application/json' // Tipo de contenido de la solicitud
        },
        body: JSON.stringify(objeto_credenciales) // Convertir el objeto de credenciales a JSON
    };

    apiwebII(options); // Llamar a la función apiwebII con las opciones configuradas
}

// Añadir el evento click al botón de login para que ejecute la función credenciales
btnLogin.addEventListener('click', credenciales);
