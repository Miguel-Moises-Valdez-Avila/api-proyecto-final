// Obtener el contenedor de tarjetas desde el DOM, proporcionar una interfaz para interactuar con el documento HTML
const cardContainer = document.getElementById('card-container'); //document: Es el objeto principal del DOM que representa el documento HTML 
                                                                    //cargado en el navegador.

// Función para crear una card
function createCard(data) {
    const cardContainer = document.createElement('div'); // Crear un nuevo div que actúa como contenedor de tarjetas
    cardContainer.className = 'row'; // Asignar la clase 'row' al contenedor }

    // Iterar sobre cada elemento en los datos proporcionados
    data.forEach(item => {
        const card = document.createElement('div'); // Crear un nuevo div para cada tarjeta
        card.className = 'col-md-4 mb-4'; // Asignar clases para diseño de columnas y margen

        // Definir el contenido HTML de la tarjeta
        card.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${item.name}</h5>
                    <p class="card-text">${item.description}</p>
                    <p class="card-text">Precio: ${item.price}</p>
                    <button class="btn btn-primary comprar-btn">Comprar</button>
                </div>
            </div>
        `;

        cardContainer.appendChild(card); // Añadir la tarjeta al contenedor de tarjetas
    });

    // Añadir event listener a cada botón "Comprar" después de crear las tarjetas
    cardContainer.querySelectorAll('.comprar-btn').forEach((button, index) => {
        button.addEventListener('click', () => {
            // Lógica para el botón "Comprar"
            const item = {
                user_id: sessionStorage.getItem('id_usuario'), // Obtener ID de usuario de sessionStorage
                item_id: data[index].id, // Obtener ID del item del array de datos
                order_date: "2024-06-05", // Fecha de la orden (puedes actualizarla dinámicamente si es necesario)
                status: "pagado" // Estado de la orden
            };
//autorizacion del token del usuario
            const options = {
                method: 'POST', // Método HTTP para la solicitud
                headers: {
                    'Content-Type': 'application/json', // Tipo de contenido de la solicitud
                    'Authorization': `${sessionStorage.getItem('token_usuario')}` // Token de autorización del usuario
                },
                body: JSON.stringify(item) // Convertir el objeto de la orden a JSON
            };

            apiwebIIComprar(options); // Llamar a la función para realizar la compra
            alert('Producto comprado y pagado'); // Mostrar mensaje de confirmación
        });
    });

    return cardContainer; // Devolver el contenedor de tarjetas
}

// Función flecha para consumir la API y obtener todos los items
const apiwebII = async () => {
    let url = "http://localhost/api-webII/v1/usuarios/item"; // URL de la API para obtener todos los items
    const api = await fetch(url); // Realizar la solicitud a la API
    const data = await api.json(); // Obtener la respuesta en formato JSON
    
    // Iterar sobre el array de objetos devueltos por la API
    for (let i = 0; i < data.length; i++) {
        const card = createCard(data[i]); // Crear una tarjeta para cada objeto
        cardContainer.appendChild(card); // Añadir la tarjeta al contenedor de tarjetas
    }
}

// Función asincrónica para realizar la compra de un item
const apiwebIIComprar = async (options) => {
    try {
        let url = "http://localhost/api-webII/v1/usuarios/comprar"; // URL de la API para realizar la compra
        const response = await fetch(url, options); // Realizar la solicitud a la API con las opciones proporcionadas
        const data = await response.json(); // Obtener la respuesta en formato JSON
        console.log(data); // Mostrar la respuesta en la consola
    } catch (error) {
        console.error('Error:', error); // Mostrar cualquier error en la consola
    }
}

// Llamar a la función para consumir la API y crear las tarjetas
apiwebII();
