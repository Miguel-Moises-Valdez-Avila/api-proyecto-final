<?php
// Requiere los archivos de conexión a la base de datos y manejo de excepciones.
require_once("./utilidades/ConexionBD.php");
require_once("./utilidades/ExcepcionApi.php");

// Definición de la clase Order
class Order
{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;

    // Datos de la tabla "orders"
    const NOMBRE_TABLA = "orders";
    const ID_User = "user_id";
    const ID_item = "item_id";
    const Order_date = "order_date";
    const Estado = "status";

    // Método para crear un nuevo registro de orden.
    public function create($id_user, $id_item, $order_date, $estado){
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

            // Sentencia SQL para insertar un nuevo registro en la tabla "orders".
            $comando = "INSERT INTO " . self::NOMBRE_TABLA . " ( " .
                self::ID_User . "," .
                self::ID_item . "," .
                self::Order_date . "," .
                self::Estado . ")" .
                " VALUES(?,?,?,?)";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);

            // Vincula los parámetros de la sentencia SQL con los valores recibidos.
            $sentencia->bindParam(1, $id_user);
            $sentencia->bindParam(2, $id_item);
            $sentencia->bindParam(3, $order_date);
            $sentencia->bindParam(4, $estado);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            // Devuelve el estado de la creación según el resultado de la ejecución.
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }

    
}
