<?php

// Requiere los archivos de conexión a la base de datos y manejo de excepciones.
require_once ("./utilidades/ConexionBD.php");
require_once ("./utilidades/ExcepcionApi.php");

// Definición de la clase Categoria
class Categoria{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;

    // Datos de la tabla "category"
    const NOMBRE_TABLA = "category";
    const NAME_CATEGORY = "name_category";

    // Método para crear una nueva categoría.
    public function crear($nombre_categoria)
    {
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

            // Sentencia SQL para insertar un nuevo registro en la tabla "category".
            $comando = "INSERT INTO " . self::NOMBRE_TABLA . " (" .
                self::NAME_CATEGORY . ")" .
                " VALUES(?)";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);

            // Vincula el parámetro de la sentencia SQL con el valor de $nombre_categoria.
            $sentencia->bindParam(1, $nombre_categoria);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            // Verifica si la inserción fue exitosa y retorna el estado correspondiente.
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }

        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }
    //Método para actualizar una categoria.
    public function update($name_category, $id)
    {
        // Código para actualizar una categoria específica.
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
            // Sentencia SQL para seleccionar todos los registros de la tabla items.
            $consulta = "UPDATE category
                     SET name_category = ?
                     WHERE id = ?";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($consulta);

            // Vincula los parámetros de la sentencia SQL con los valores del item.
            $sentencia->bindParam(1, $name_category);
            $sentencia->bindParam(2, $id);
            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }
    // Método para recuperar todos los registros de la tabla items.
    public function all()
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
        // Sentencia SQL para seleccionar todos los registros de la tabla items.
        $consulta = 'SELECT * FROM category';
        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($consulta);
        // Ejecuta la sentencia SQL.
        $sentencia->execute();
        // Devuelve todos los registros obtenidos en un array asociativo.
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }
    public function destroy($id_categoria)
    {
        // Método que eliminará un registro.
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
            // Sentencia SQL 
            $comando = "DELETE FROM category WHERE id=?";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);
            $sentencia->bindParam(1, $id_categoria);
            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }
}
