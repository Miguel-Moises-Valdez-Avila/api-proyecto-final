<?php
// Definición de la clase Item
class Item
{

    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;

    // Datos de la tabla "items"
    const NOMBRE_TABLA = "items";
    const NAME_ITEM = "name";
    const PRECIO_ITEM = "price";
    const DESCRIPCION_ITEM = "description";
    const CATEGORIA_ID = "category_id";

    // Método para recuperar todos los registros de la tabla items.
    public function all()
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
        // Sentencia SQL para seleccionar todos los registros de la tabla items.
        $consulta = 'SELECT * FROM items';
        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($consulta);
        // Ejecuta la sentencia SQL.
        $sentencia->execute();
        // Devuelve todos los registros obtenidos en un array asociativo.
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para crear un nuevo item.
    public function crear($nombre_item, $precio_item, $descripcion_item, $categoria_id)
    {
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

            // Sentencia SQL para insertar un nuevo registro en la tabla "items".
            $comando = "INSERT INTO " . self::NOMBRE_TABLA . " (" .
                self::NAME_ITEM . "," .
                self::PRECIO_ITEM . "," .
                self::DESCRIPCION_ITEM . "," .
                self::CATEGORIA_ID . ")" .
                " VALUES(?,?,?,?)";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);

            // Vincula los parámetros de la sentencia SQL con los valores del item.
            $sentencia->bindParam(1, $nombre_item);
            $sentencia->bindParam(2, $precio_item);
            $sentencia->bindParam(3, $descripcion_item);
            $sentencia->bindParam(4, $categoria_id);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }

    // Método para actualizar un registro.
    public function update($name, $description, $price, $category_id, $id_item)
    {
        // Código para actualizar un item específico.
        try {

            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
            // Sentencia SQL para seleccionar todos los registros de la tabla items.
            $consulta = "UPDATE items
                     SET name = ?, description = ?, price = ?, category_id = ? 
                     WHERE id = ?";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($consulta);

            // Vincula los parámetros de la sentencia SQL con los valores del item.
            $sentencia->bindParam(1, $name);
            $sentencia->bindParam(2, $description);
            $sentencia->bindParam(3, $price);
            $sentencia->bindParam(4, $category_id);
            $sentencia->bindParam(5, $id_item);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }


    public function find($id_item)
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

        // Sentencia SQL para insertar un nuevo registro en la tabla "items".
        $comando = "SELECT * FROM items WHERE id=?";

        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($comando);
        $sentencia->bindParam(1, $id_item);
        // Ejecuta la sentencia SQL.
        $sentencia->execute();
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }

    public function destroy($id_item)
    {
        // Método que eliminará un registro.
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();
            // Sentencia SQL para insertar un nuevo registro en la tabla "items".
            $comando = "DELETE FROM items WHERE id=?";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);
            $sentencia->bindParam(1, $id_item);
            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }
}
