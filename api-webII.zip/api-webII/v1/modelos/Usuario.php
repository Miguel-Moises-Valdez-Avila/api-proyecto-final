<?php

// Requiere los archivos de conexión a la base de datos y manejo de excepciones.
require_once("./utilidades/ConexionBD.php");
require_once("./utilidades/ExcepcionApi.php");

// Definición de la clase Usuario
class Usuario
{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;
    const ESTADO_CLAVE_NO_AUTORIZADA = 0;
    const ESTADO_AUSENCIA_CLAVE_API = 0;

    // Datos de la tabla "users"
    const NOMBRE_TABLA = "users";
    const NOMBRE = "username";
    const CONTRASENA = "password";
    const CORREO = "email";

    // Método para crear un nuevo usuario.
    public function crear($datosUsuario, $contrasenaEncriptada)
    {
        // Extracción de datos del array $datosUsuario.
        $nombre = $datosUsuario['username'];
        $correo = $datosUsuario['email'];

        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

            // Sentencia SQL para insertar un nuevo registro en la tabla "users".
            $comando = "INSERT INTO " . self::NOMBRE_TABLA . " ( " .
                self::NOMBRE . "," .
                self::CONTRASENA . "," .
                self::CORREO . ")" .
                " VALUES(?,?,?)";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);

            // Vincula los parámetros de la sentencia SQL con los valores del nombre, la contraseña encriptada y el correo.
            $sentencia->bindParam(1, $nombre);
            $sentencia->bindParam(2, $contrasenaEncriptada);
            $sentencia->bindParam(3, $correo);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            // Devuelve el estado de la creación según el resultado de la ejecución.
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }

    // Método para obtener todos los IDs de los usuarios.
    public function id_usuario()
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

        // Sentencia SQL para obtener todos los IDs de los usuarios.
        $consulta = 'SELECT id FROM users';

        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($consulta);

        // Ejecuta la sentencia SQL.
        $sentencia->execute();

        // Devuelve todos los IDs obtenidos en un array asociativo.
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para verificar la validez de las credenciales del usuario.
    public function autenticar($correo, $contrasena)
    {
        // Sentencia SQL para obtener la contraseña del usuario por su correo.
        $comando = "SELECT password FROM " . self::NOMBRE_TABLA .
            " WHERE " . self::CORREO . "=?";

        try {
            // Prepara la sentencia SQL.
            $sentencia = ConexionBD::obtenerInstancia()->obtenerBD()->prepare($comando);
            $sentencia->bindParam(1, $correo);
            $sentencia->execute();

            if ($sentencia) {
                $resultado = $sentencia->fetch();
                // Verifica si la contraseña proporcionada coincide con la contraseña en la base de datos.
                if (self::validarContrasena($contrasena, $resultado['password'])) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }

    // Método para obtener los detalles del usuario por su correo.
    public function obtenerUsuarioPorCorreo($correo)
    {
        // Sentencia SQL para obtener los detalles del usuario por su correo.
        $comando = "SELECT users.id, users.username, users.password, users.email, token.string_token
                    FROM users
                    INNER JOIN token ON users.id = token.usuario_id
                    WHERE " . self::CORREO . "=?";

        // Prepara la sentencia SQL.
        $sentencia = ConexionBD::obtenerInstancia()->obtenerBD()->prepare($comando);
        $sentencia->bindParam(1, $correo);

        // Ejecuta la sentencia SQL y devuelve los datos del usuario si se encuentra, de lo contrario, devuelve null.
        if ($sentencia->execute())
            return $sentencia->fetch(PDO::FETCH_ASSOC);
        else
            return null;
    }

    // Método estático para validar la contraseña proporcionada contra la almacenada en la base de datos.
    public static function validarContrasena($contrasenaPlana, $contrasenaHash)
    {
        return password_verify($contrasenaPlana, $contrasenaHash);
    }

    // Método para encontrar al usuario por su ID.
    public function find($id_usuario)
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

        // Sentencia SQL para obtener los detalles del usuario por su ID.
        $comando = "SELECT * FROM users WHERE id=?";

        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($comando);
        $sentencia->bindParam(1, $id_usuario);

        // Ejecuta la sentencia SQL.
        $sentencia->execute();

        // Devuelve los detalles del usuario.
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }
}
