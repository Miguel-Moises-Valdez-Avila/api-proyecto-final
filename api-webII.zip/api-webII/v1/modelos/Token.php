<?php

// Requiere los archivos de conexión a la base de datos y manejo de excepciones.
require_once("./utilidades/ConexionBD.php");
require_once("./utilidades/ExcepcionApi.php");

// Definición de la clase Token
class Token{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;

    // Datos de la tabla "token"
    const ID_USUARIO = "id";
    const NOMBRE_TABLA = "token";
    const STRING_TOKEN = "string_token";
    const USUARIO_ID = "usuario_id";

    // Método para crear un nuevo token.
    public function crear($token, $id_usuario)
    {
        try {
            // Obtiene una instancia de la conexión a la base de datos.
            $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

            // Sentencia SQL para insertar un nuevo registro en la tabla "token".
            $comando = "INSERT INTO " . self::NOMBRE_TABLA . " (" .
                self::STRING_TOKEN . "," .
                self::USUARIO_ID . ")" .
                " VALUES(?,?)";

            // Prepara la sentencia SQL.
            $sentencia = $pdo->prepare($comando);

            // Vincula los parámetros de la sentencia SQL con los valores del token y del ID de usuario.
            $sentencia->bindParam(1, $token);
            $sentencia->bindParam(2, $id_usuario);

            // Ejecuta la sentencia SQL.
            $resultado = $sentencia->execute();

            // Verifica si la creación fue exitosa y devuelve el estado correspondiente.
            if ($resultado) {
                return self::ESTADO_CREACION_EXITOSA;
            } else {
                return self::ESTADO_CREACION_FALLIDA;
            }

        } catch (PDOException $e) {
            // Si ocurre una excepción, lanza una ExcepcionApi con el mensaje de error.
            throw new ExcepcionApi(self::ESTADO_ERROR_BD, $e->getMessage());
        }
    }

    // Método para validar un token.
    public static function validarToken($token)
    {
        // Obtiene una instancia de la conexión a la base de datos.
        $pdo = ConexionBD::obtenerInstancia()->obtenerBD();

        // Sentencia SQL para buscar un token en la tabla "token".
        $comando = "SELECT string_token FROM token WHERE string_token=?";

        // Prepara la sentencia SQL.
        $sentencia = $pdo->prepare($comando);
        $sentencia->bindParam(1, $token);

        // Ejecuta la sentencia SQL.
        $sentencia->execute();

        // Devuelve los resultados obtenidos.
        return $sentencia->fetchAll(PDO::FETCH_ASSOC);
    }  
}
