<?php
// Permitir solicitudes desde cualquier origen (CORS)
header('Access-Control-Allow-Origin: *');

// Permitir ciertos encabezados en las solicitudes CORS
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");

// Permitir todos los encabezados en las solicitudes CORS
header("Access-Control-Allow-Headers: *");

// Incluir archivos necesarios para las vistas y controladores
require_once "vistas/VistaJson.php";
require_once "./modelos/Usuario.php";
require_once './controladores/Auth/RegistroController.php';
require_once './controladores/Auth/LoginController.php';
require_once './controladores/CategoriaController.php';
require_once './controladores/ItemController.php';
require_once './controladores/TokenController.php';
require_once './controladores/OrderController.php';
require '../vendor/autoload.php'; // Requiere el archivo autoload.php del paquete Composer

//Manejo de excepciones de la api,  cuando un comportamiento no esta pasando
$vista = new VistaJson();
//
set_exception_handler(function ($exception) use ($vista) {
    $cuerpo = array(
        "estado" => $exception->estado,
        "mensaje" => $exception->getMessage()
    );
    if ($exception->getCode()) {
        $vista->estado = $exception->getCode();
    } else {
        $vista->estado = 500;
    }

    $vista->imprimir($cuerpo);
}
);
// Definir una constante para el estado de método no permitido
const ESTADO_METODO_NO_PERMITIDO = 2;
const ESTADO_EXISTENCIA_RECURSO = 3;
// Crear una instancia de la vista para mostrar la respuesta
$vista = new VistaJson();

// Obtener la URI de la petición
$uri = $_GET['PATH_INFO'];// Se usa para meter PATH_INFO
//var_dump($uri); // se usa para mostrar lo que tenemos en la variable
//exit;
// Dividir la URI en partes
$peticion = explode('/', $uri);
$recurso = array_shift($peticion);
//lista de recursos existentes
$recursos_existentes = array('usuarios', 'productos', 'categorias', 'orders');
//comprobar si el recurso solicitado existe
if (!in_array($recurso, $recursos_existentes)) {
    // si no existe el recurso, responder con un error(código no implementado)
    throw new ExcepcionApi(ESTADO_EXISTENCIA_RECURSO,
    "No se reconoce el recurso al que intentas acceder");
}
// Obtener el método HTTP de la petición y convertirlo a minúsculas
$metodo = strtolower($_SERVER['REQUEST_METHOD']);

// Procesar la petición según el método HTTP
switch ($metodo) {
    case 'get':
        // Si el primer elemento de la petición es "item"
        if ($peticion[0] == "item") {
            // Crear una instancia del controlador de ítems y mostrar todos los ítems
            $items_controller = new ItemController();
            $vista->imprimir($items_controller->index());
        } else if ($peticion[0] == "producto") {
            // Si el primer elemento de la petición es "producto"
            // Crear una instancia del controlador de ítems y mostrar un ítem específico
            $producto = new ItemController();
            $vista->imprimir($producto->show($peticion));
        } 
        // Crear una instancia del controlador de categoria y actualizar una categoria
        $categoria = new CategoriaController();
        $vista->imprimir($categoria->Category());
        // Procesar método GET
        break;

    case 'post':
        // Si el primer elemento de la petición es "categoria"
        if ($peticion[0] == "categoria") {//identificador categoria
            // Crear una instancia del controlador de categorías y guardar la categoría
            $categoria = new CategoriaController();
            $vista->imprimir($categoria->store());
        } else if ($peticion[0] == "item") {//identificador item
            // Si el primer elemento de la petición es "item"
            // Crear una instancia del controlador de ítems y guardar el ítem
            $item = new ItemController();
            $vista->imprimir($item->store());
        }else if($peticion[0] == "comprar"){//identificador comprar
            // Si el primer elemento de la petición es "comprar"
            // Crear una instancia del controlador de órdenes y procesar la petición de compra
            $orden_user = new OrderController();
            $vista->imprimir($orden_user->store());
        }else if($peticion[0] == "login"){//identificador login
            // Si el primer elemento de la petición es "login"
            // Crear una instancia del controlador de login y procesar la petición de login
            $login_controller = new LoginController();
            $vista->imprimir($login_controller->post($peticion));
        }
        // Crear una instancia del controlador de registro y procesar la petición de registro
        $registro_controller = new RegistroController();
        $vista->imprimir($registro_controller->post($peticion));
        // Procesar método POST
        break;
        
    case 'put':
         //si el metodo es put(atualizar)
         if($peticion[0] == "categoria"){
            // Crear una instancia del controlador de categoria y actualizar una categoria
            $categoria = new CategoriaController();
            $vista->imprimir($categoria->update($peticion));
        }
        // Si el método es PUT
        // Crear una instancia del controlador de ítems y actualizar un ítem
        $item = new ItemController();
        $vista->imprimir($item->update($peticion));
        // Procesar método PUT
        break;

    case 'delete':
          // Si el método es DELETE
        if($peticion[0] == "categoria"){
            // Crear una instancia del controlador de ítems y eliminar un ítem
            $categoria = new CategoriaController();
            $vista->imprimir($categoria->delete($peticion));
        }
        break;
    default:
        // Si el método HTTP no es reconocido, no hacer nada (código no implementado)
        break;
}
