<?php

// Requiere los archivos Usuario.php y TokenController.php, donde se definen las clases correspondientes.
require_once '../v1/modelos/Usuario.php';
require_once './controladores/TokenController.php';

// Definición de la clase RegistroController
class RegistroController{

    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_URL_INCORRECTA = "Url mal formada"; // URL no válida
    const ESTADO_CREACION_EXITOSA = 200; // Creación exitosa
    const ESTADO_CREACION_FALLIDA = 401; // Creación fallida (no autorizado)
    const ESTADO_ERROR_BD = 500; // Error en la base de datos
    const ESTADO_FALLA_DESCONOCIDA = 501; // Falla desconocida

    //Validacion de mis rutas
    // Método principal que recibe una petición POST y decide la acción a tomar.
    public function post($peticion)
    {
        // Verifica si la petición es para registro o login.
        if ($peticion[0] == 'registro') {
            // Si la petición es para registro, llama al método registrar().
            return $this->registrar();
        } else if ($peticion[0] == 'login') {
            // Código comentado para manejar el login.
            // return self::loguear();
        } else {
            // Si la URL no es correcta, lanza una excepción con el estado correspondiente.
            throw new ExcepcionApi(self::ESTADO_URL_INCORRECTA, 400);
        }
    }

    // Método para manejar el registro de un nuevo usuario.
    public function registrar()
    {
        // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
        //El string php://input es de solo lectura,el cual permite leer datos del body solicitado sin ningun proceso
        $cuerpo = file_get_contents('php://input');
        $usuario = json_decode($cuerpo, true);

        // Encripta la contraseña usando password_hash.
        $contraseña_encriptada =  $this->encriptarContrasena($usuario['password']);

        // Crea una instancia del modelo Usuario.
        $crear_usuario = new Usuario();

        // Llama al método crear del modelo Usuario, pasando los datos del usuario junto con la contraseña encriptada.
        $resultado = $crear_usuario->crear($usuario, $contraseña_encriptada);

        // Genera el token del usuario usando la librería JWT a través de TokenController.
        $generar_token_usuario = new TokenController();
        $generar_token_usuario->genera_token($usuario);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($resultado) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "¡Registro con éxito!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }

    // Método para encriptar la contraseña.
    public function encriptarContrasena($contrasenaPlana)
    {
        // Si se proporciona una contraseña, la encripta usando password_hash.
        if ($contrasenaPlana)
            return password_hash($contrasenaPlana, PASSWORD_DEFAULT);
        else return null;
    }
}
?>
