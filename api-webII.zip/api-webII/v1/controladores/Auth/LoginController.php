<?php

// Requiere el archivo Usuario.php, donde se define la clase Usuario.
require_once '../v1/modelos/Usuario.php';

// Definición de la clase LoginController
class LoginController
{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_URL_INCORRECTA = "Url mal formada"; // URL no válida
    const ESTADO_CREACION_EXITOSA = 200; // Creación exitosa
    const ESTADO_CREACION_FALLIDA = 401; // Creación fallida (no autorizado)
    const ESTADO_ERROR_BD = 500; // Error en la base de datos
    const ESTADO_FALLA_DESCONOCIDA = 501; // Falla desconocida
    const ESTADO_PARAMETROS_INCORRECTOS = 1; // Parámetros incorrectos

    // Método principal que recibe una petición POST y decide la acción a tomar.
    public function post($peticion)
    {
        // Verifica si la petición es para registro o login.
        if ($peticion[0] == 'registro') {
            // Código comentado para registrar un nuevo usuario.
            // return $this->registrar();
        } else if ($peticion[0] == 'login') {
            // Si la petición es para login, llama al método loguear().
            return $this->loguear();
        } else {
            // Si la URL no es correcta, lanza una excepción con el estado correspondiente.
            throw new ExcepcionApi(self::ESTADO_URL_INCORRECTA, 400);
        }
    }

    // Método para manejar el proceso de login.
    public function loguear()
    {
        // Array para almacenar la respuesta.
        $respuesta = array();

        // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
        //El string php://input es de solo lectura,el cual permite leer datos del body solicitado sin ningun proceso
        $body = file_get_contents('php://input');
        $usuario = json_decode($body, true);

        // Extrae el correo y la contraseña del usuario.
        $correo = $usuario['email'];
        $contrasena = $usuario['password'];

        // Crea una nueva instancia de la clase Usuario.
        $usuario = new Usuario();

        // Autentica al usuario con el correo y la contraseña proporcionados.
        if ($usuario->autenticar($correo, $contrasena)) {
            // Si la autenticación es exitosa, obtiene los datos del usuario por su correo.
            $usuarioBD = $usuario->obtenerUsuarioPorCorreo($correo);
            
            // Si el usuario existe en la base de datos, devuelve los detalles del usuario.
            if ($usuarioBD != NULL) {
                http_response_code(200); // Código de respuesta HTTP 200 OK.
                $respuesta["id"] = $usuarioBD["id"];
                $respuesta["nombre"] = $usuarioBD["username"];
                $respuesta["correo"] = $usuarioBD["email"];
                $respuesta["token"] = $usuarioBD["string_token"];
                return [$respuesta]; // Devuelve la respuesta.
            } else {
                // Si ocurre un error desconocido, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(
                    self::ESTADO_FALLA_DESCONOCIDA,
                    "Ha ocurrido un error"
                );
            }
        } else {
            // Si la autenticación falla, lanza una excepción con el estado correspondiente.
            throw new ExcepcionApi(
                self::ESTADO_PARAMETROS_INCORRECTOS,
                utf8_encode("Correo o contraseña inválidos")
            );
        }
    }
}
?>
