<?php

// Utiliza las clases JWT y Key de la librería Firebase JWT para manejar la creación y validación de tokens.
use Firebase\JWT\JWT;

// Requiere los archivos Usuario.php y Token.php, donde se definen las clases correspondientes.
require_once './modelos/Usuario.php';
require_once './modelos/Token.php';

// Definición de la clase TokenController
class TokenController{

    // Método para generar un token JWT.
    public function genera_token($body){

        // Llave que se utilizará para cifrar los datos del token.
        $key = "datos_usuario";

        // Se obtiene el ID del usuario.
        $id_usuario = new Usuario();
        $ids = $id_usuario->id_usuario();

        // Se extrae el ID del usuario del array de resultados.
        $array_id = array();
        foreach($ids as $id){
            $array_id = $id;
        }

        // Se crea el payload, que es la información que se quiere encriptar en el token.
        $payload = array(
            "id" =>  $array_id['id'],
            "nombre" => $body['username'],
            "correo" => $body['email']
        );

        // Se utiliza el método encode de JWT para encriptar y generar el token.
        // Se pasa el payload, la llave y el algoritmo de cifrado (HS256).
        $jwt_token = JWT::encode($payload, $key, 'HS256');

        // Se crea una instancia del modelo Token y se guarda el token generado en la base de datos junto con el ID del usuario.
        $token_usuario = new Token();
        $token_usuario->crear($jwt_token, $array_id['id']);

        // Código comentado para decodificar el token, en caso de necesitarlo.
        // $decoded = JWT::decode($jwt, new Key($key, 'HS256'));
    }
}
