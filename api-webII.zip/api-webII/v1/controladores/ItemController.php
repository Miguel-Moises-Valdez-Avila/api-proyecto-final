<?php

// Requiere el archivo Item.php, donde se define la clase Item.
require_once './modelos/Item.php';

// Definición de la clase ItemController
class ItemController{
    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_URL_INCORRECTA = "Url mal formada";
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;
    const ESTADO_FALLA_DESCONOCIDA = 501;

    // Método para recuperar todos los registros de la tabla items.
    public function index(){
        // Crea una instancia del modelo Item.
        $item = new Item();
        // Llama al método all del modelo Item para obtener todos los registros.
        $todos_los_items =  $item->all();
        // Devuelve todos los registros obtenidos en un array.
        return [
            $todos_los_items
        ];
    }

    // Método para manejar la creación de un nuevo item.
    public function store(){
        // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
        $cuerpo = file_get_contents('php://input');
        $usuario = json_decode($cuerpo, true);

        // Extrae los datos del item desde el JSON decodificado.
        $nombre_item = $usuario['nombre_item'];
        $precio_item = $usuario['precio_item'];
        $descripcion_item = $usuario['descripcion_item'];
        $categoria_id = $usuario['categoria_id'];

        // Crea una instancia del modelo Item.
        $item = new Item();
        // Llama al método crear del modelo Item, pasando los datos del item.
        $insertar_item = $item->crear($nombre_item, $precio_item, $descripcion_item, $categoria_id);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($insertar_item) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "¡Item insertado!"
                ];  
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }

    // Método para mostrar un recurso mediante id
    public function show($peticion){
        $producto = new Item();
        $producto_user = $producto->find($peticion[1]);
        $product = array();
        foreach($producto_user as $peticion){
            $product = $peticion;
        }
        return $product;
    }

    // Método para actualizar un registro 
    public function update($id_item){
        // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
        //El string php://input es de solo lectura,el cual permite leer datos del body solicitado sin ningun proceso
        $cuerpo = file_get_contents('php://input');
        $item = json_decode($cuerpo, true);

        // Extrae los datos del item desde el JSON decodificado.
        $nombre_item = $item['nombre_item'];
        $precio_item = $item['precio_item'];
        $descripcion_item = $item['descripcion_item'];
        $categoria_id = $item['categoria_id'];

        $update = new Item();
        //el método update retorna un valor, si se cumple retornará 200, ese número se guarda en la 
        //variable update_item, posteriormente se evalúa el caso.
        $update_item = $update->update($nombre_item, $descripcion_item, $precio_item,  $categoria_id, $id_item[1]);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($update_item) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "¡Item actualizado!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }

    // Método para borrar un recurso
    public function delete($id_item){
        // Código para borrar un item específico .

        $delete = new Item();
        $delete_item = $delete->destroy($id_item[1]);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($delete_item) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "¡Item eliminado!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }
}
?>

