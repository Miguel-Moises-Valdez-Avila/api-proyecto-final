<?php
require_once '../fpdf/fpdf.php'; // Se incluye la biblioteca FPDF para la generación de PDFs
require_once './modelos/Order.php'; // Se incluye el modelo Order
require_once './modelos/Item.php'; // Se incluye el modelo Item
require_once './modelos/Usuario.php'; // Se incluye el modelo Usuario
require_once './modelos/Token.php'; // Se incluye el modelo Token

class OrderController
{
    // Constantes para los diferentes estados de respuesta
    const ESTADO_URL_INCORRECTA = "Url mal formada";
    const ESTADO_CREACION_EXITOSA = 200;
    const ESTADO_CREACION_FALLIDA = 401;
    const ESTADO_ERROR_BD = 500;
    const ESTADO_FALLA_DESCONOCIDA = 501;

    public function store()
    {
        // Se recuperan los encabezados de la solicitud
        $cabeceras = apache_request_headers();
        // Se extrae el token de la cabecera Authorization
        $token = $cabeceras['Authorization'];

        // Se valida el token
        $token_usuario = new Token();
        $token_comprobar = $token_usuario->validarToken($token);
        $token_usuario = array();
        foreach ($token_comprobar as $tk) {
            $token_usuario = $tk;
        }

        // Se obtiene el cuerpo de la solicitud
        //El string php://input es de solo lectura,el cual permite leer datos del body solicitado sin ningun proceso
        $cuerpo = file_get_contents('php://input');
        $body = json_decode($cuerpo, true); // Se decodifica el cuerpo de la solicitud a un array asociativo

        // Variables
        $usuario_id = $body["user_id"];
        $item_id = $body["item_id"];
        $order_date = $body["order_date"];
        $status = $body["status"];

        // Se crea una nueva orden
        $orden = new Order();
        // Obtener los detalles del item
        $item_model = new Item();
        $item_compra = $item_model->find($item_id);
        $orden_user = $orden->create($usuario_id, $item_id, $order_date, $status);

        $item = array();
        foreach ($item_compra as $compra) {
            $item = $compra;
        }

        // Generar recibo después de la creación del pedido
        $this->generar_recibo($item, $order_date, $status, $usuario_id);

        // Evalúa la respuesta del método crear usando una estructura switch
        switch ($orden_user) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito
                http_response_code(200);
                return [
                    "mensaje" => "¡Producto Comprado y pagado!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }

    // Generación del pdf
    public function generar_recibo($item_compra, $order_date, $status, $usuario_id)
    {
        // Recuperar al usuario
        $usuarios = new Usuario();
        $usuario = $usuarios->find($usuario_id);

        $usuario_compra = array();
        foreach ($usuario as $user) {
            $usuario_compra = $user;
        }
        //variable para optener la fecha y minutos
        $fecha_fecha_pdf =  date('Y-m-d H:i:s');//formato para obtener la fecha
        $cadenaModificada = str_replace(':', '-', $fecha_fecha_pdf);//modificacion de caracteres : a -
        // Nombre del archivo
        $archivo_ticker_nombre = 'recibo_ticket_' . $cadenaModificada .  $usuario_compra['username'] . '.pdf';
        // Ruta del archivo
        $ruta_pdf = './recibo_pdf/' . $archivo_ticker_nombre;

        // Crear un nuevo objeto FPDF
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);

        // Agregar contenido al PDF
        $pdf->Cell(0, 10, 'Tu Recibo de Compra ' . $usuario_compra['username'], 0, 1, 'C');
        $pdf->Cell(0, 10, "ID de la compra: " . $item_compra["id"], 0, 'C', 0);
        $pdf->Cell(0, 10, "Producto: " . $item_compra["name"], 0, 'C', 0);
        $pdf->Cell(0, 10, "Precio Producto: " . $item_compra["price"], 0, 'C', 0);
        $pdf->Cell(0, 10, utf8_decode("Descripcion: " . $item_compra["description"]), 0, 'C', 0);
        $pdf->Cell(0, 10, 'Fecha Orden: ' . $order_date, 0, 'C', 0);
        $pdf->Cell(0, 10, 'Status: ' . $status, 0, 1);

        // Guardar el archivo PDF
        $pdf->Output('F', $ruta_pdf, true);
    }


    
}
?>
