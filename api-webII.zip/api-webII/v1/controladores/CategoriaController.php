<?php

// Requiere el archivo Categoria.php, donde se define la clase Categoria.
require_once './modelos/Categoria.php';

// Definición de la clase CategoriaController
class CategoriaController{

    // Constantes para definir distintos estados y mensajes de error.
    const ESTADO_URL_INCORRECTA = "Url mal formada"; // URL no válida
    const ESTADO_CREACION_EXITOSA = 200; // Creación exitosa
    const ESTADO_CREACION_FALLIDA = 401; // Creación fallida (no autorizado)
    const ESTADO_ERROR_BD = 500; // Error en la base de datos
    const ESTADO_FALLA_DESCONOCIDA = 501; // Falla desconocida

    // Método para manejar la creación de una nueva categoría.
    //Agregar una categoria
    public function store(){
        // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
        //El string php://input es de solo lectura,el cual permite leer datos del body solicitado sin ningun proceso
        $cuerpo = file_get_contents('php://input');
        $usuario = json_decode($cuerpo, true);// el json decode sirve para convertir los datos de formato json a formato php

        // Crea una instancia del modelo Categoria.
        $categoria = new Categoria();
        // Llama al método crear del modelo Categoria, pasando el nombre de la categoría.
        $insertar_categoria = $categoria->crear($usuario["nombre_categoria"]);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($insertar_categoria) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "¡Categoria Insertada!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }
//Método para actualizar una categoría.
public function update($id_categoria){

    // Obtiene el cuerpo de la solicitud y lo decodifica desde JSON.
    $cuerpo = file_get_contents('php://input');
    $categoria = json_decode($cuerpo, true);

     // Extrae los datos de la categoria desde el JSON decodificado.
     $name_category = $categoria['name_category'];

    // Crea una instancia del modelo Categoria.
    $update = new Categoria();
    
    // Llama al método actualizar del modelo Categoria, pasando el ID y los nuevos datos.
    $update_category = $update->update($name_category, $id_categoria[1]);

    // Evalúa la respuesta del método actualizar usando una estructura switch.
    switch ($update_category) {
        case self::ESTADO_CREACION_EXITOSA:
            // Si la actualización fue exitosa, devuelve un mensaje de éxito.
            http_response_code(200);
            return [
                "mensaje" => "Categoria actualizada!"
            ];
            break;
        case self::ESTADO_CREACION_FALLIDA:
            // Si la actualización falló, lanza una excepción con el estado correspondiente.
            throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
            break;
        default:
            // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
            throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
    }
}
    // Método para recuperar todos los registros de la tabla categoria.
    public function Category(){
        // Crea una instancia del modelo categoria.
        $categoria = new Categoria();
        // Llama al método all del modelo categoria para obtener todos los registros.
        $todas_las_categorias =  $categoria->all();
        // Devuelve todos los registros obtenidos en un array.
        return [
            $todas_las_categorias
        ];
    }
    // Método para borrar un recurso
    public function delete($id_categoria){
        // Código para borrar una categoria específica .

        $delete = new Categoria();
        $delete_categoria = $delete->destroy($id_categoria[1]);

        // Evalúa la respuesta del método crear usando una estructura switch.
        switch ($delete_categoria) {
            case self::ESTADO_CREACION_EXITOSA:
                // Si la creación fue exitosa, devuelve un mensaje de éxito.
                http_response_code(200);
                return [
                    "mensaje" => "Categoria eliminada!"
                ];
                break;
            case self::ESTADO_CREACION_FALLIDA:
                // Si la creación falló, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_CREACION_FALLIDA, "Ha ocurrido un error");
                break;
            default:
                // Si ocurre una falla desconocida, lanza una excepción con el estado correspondiente.
                throw new ExcepcionApi(self::ESTADO_FALLA_DESCONOCIDA, "Falla desconocida", 400);
        }
    }
}
?>
