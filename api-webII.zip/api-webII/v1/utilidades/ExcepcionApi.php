<?php

// Definición de la clase ExcepcionApi que extiende de la clase base Exception
class ExcepcionApi extends Exception
{
    public $estado;
    public function __construct($estado, $mensaje, $codigo = 400)
    {
        $this->estado = $estado;
        $this->message = $mensaje;
        $this->code = $codigo;
    }
}