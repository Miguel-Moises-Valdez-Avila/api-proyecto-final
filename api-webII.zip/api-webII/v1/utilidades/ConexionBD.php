<?php
/**
 * Clase que envuelve una instancia de la clase PDO
 * para el manejo de la base de datos
 */

// Se requiere el archivo de configuración para la conexión a la base de datos.
require_once 'datos/login_mysql.php';

class ConexionBD
{
    /**
     * Única instancia de la clase
     */
    private static $db = null;

    /**
     * Instancia de PDO
     */
    private static $pdo;

    /**
     * Constructor privado para evitar la creación de instancias directamente.
     */
    final private function __construct()
    {
        try {
            // Crear nueva conexión PDO
            self::obtenerBD();
        } catch (PDOException $e) {
            // Manejo de excepciones (puede incluir logging, rethrow, etc.)
        }
    }

    /**
     * Retorna la única instancia de la clase.
     * Implementa el patrón Singleton.
     * @return ConexionBD|null
     */
    public static function obtenerInstancia()
    {
        // Si no hay una instancia creada, se crea una nueva.
        if (self::$db === null) {
            self::$db = new self();
        }
        // Devuelve la instancia única.
        return self::$db;
    }

    /**
     * Crear una nueva conexión PDO basada
     * en las constantes de conexión.
     * @return PDO Objeto PDO
     */
    public function obtenerBD()
    {
        // Si la conexión PDO no ha sido creada, se crea una nueva.
        if (self::$pdo == null) {
            self::$pdo = new PDO(
                'mysql:dbname=' . BASE_DE_DATOS .
                ';host=' . NOMBRE_HOST . ";",
                USUARIO,
                CONTRASENA,
                array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
            );

            // Habilitar excepciones para el manejo de errores en PDO.
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        // Devuelve la instancia de PDO.
        return self::$pdo;
    }

    /**
     * Evita la clonación del objeto.
     * Implementa el patrón Singleton.
     */
    final protected function __clone()
    {
    }

    /**
     * Destructor de la clase.
     * Libera la conexión PDO.
     */
    function _destructor()
    {
        self::$pdo = null;
    }
}
